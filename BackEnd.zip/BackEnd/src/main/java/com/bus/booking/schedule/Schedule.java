package com.bus.booking.schedule;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Schedule {
    @Id
    @GeneratedValue
    @Column(name = "schedule_id")
    private int id;

    @Column
    private String date = LocalDate.now().format(DateTimeFormatter.ofPattern("MMM dd, yyyy"));
    
    @Column
    private String bus;
    
    @Column
    private String startingpoint;
    
    @Column
    private String destination;
    
    @Column
    private String time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
    
    @Column
    private String etadate = LocalDate.now().format(DateTimeFormatter.ofPattern("MMM dd, yyyy"));
    
    @Column
    private String etatime = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
    
    @Column
    private int availability;
    
    @Column
    private int price;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getBus() {
		return bus;
	}

	public void setBus(String bus) {
		this.bus = bus;
	}

	public String getStartingpoint() {
		return startingpoint;
	}

	public void setStartingpoint(String startingpoint) {
		this.startingpoint = startingpoint;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getEtadate() {
		return etadate;
	}

	public void setEtadate(String etadate) {
		this.etadate = etadate;
	}

	public String getEtatime() {
		return etatime;
	}

	public void setEtatime(String etatime) {
		this.etatime = etatime;
	}

	public int getAvailability() {
		return availability;
	}

	public void setAvailability(int availability) {
		this.availability = availability;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Schedule(int id, String date, String bus, String startingpoint, String destination, String time,
			String etadate, String etatime, int availability, int price) {
		super();
		this.id = id;
		this.date = date;
		this.bus = bus;
		this.startingpoint = startingpoint;
		this.destination = destination;
		this.time = time;
		this.etadate = etadate;
		this.etatime = etatime;
		this.availability = availability;
		this.price = price;
	}

	public Schedule() {
		super();
	}
}
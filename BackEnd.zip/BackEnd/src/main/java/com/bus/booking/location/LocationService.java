package com.bus.booking.location;

import java.util.List;

 interface LocationService {

    int register(Location loc);

    boolean update(Location loc);

    Location getLocation(int locID);

    List<Location> getAllLocations();

    boolean delete(int locID);
    
    Location findByTerminal(String terminal);

}

package com.bus.booking.location;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * Implementation for User Service
 */
@Repository
public class LocationServiceImpl implements LocationService {   

    /**
     * Autowired UserRepository
     */
    @Autowired
    private LocationRepository locRepository;


	@Override
	public int register(Location loc) {
		 locRepository.save(loc);
	        return loc.getId();
	}

	@Override
	public boolean update(Location locNew) {
		   Location locOld = locRepository.findById(locNew.getId()).orElse(null);
	        if (locOld != null) {
	            locOld.setTerminal(locNew.getTerminal());
	            locOld.setCity(locNew.getCity());
	            locOld.setState(locNew.getState());
	            locRepository.save(locOld);
	            return true;
	        }
	        return false;
	}

	@Override
	public Location getLocation(int locID) {
		 return locRepository.findById(locID).orElse(null); 
	}

	@Override
	public List<Location> getAllLocations() {
        return locRepository.findAll();
	}
	
	  @Override
	    public boolean delete(int id) {
	        Location loc = locRepository.findById(id).orElse(null);
	        if (loc != null) {
	            locRepository.delete(loc);
	            return true;
	        }
	        return false;
	    }

	@Override
	public Location findByTerminal(String terminal) {
		if (locRepository.findByTerminal(terminal) != null) {
            return locRepository.findByTerminal(terminal);
        }
		return new Location();
	}
}

package com.bus.booking.location;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Location {
    @Id
    @GeneratedValue
    @Column(name = "loc_id")
    private int id;

    @Column(length = 20)
    private String terminal;
    
    @Column(length = 20)
    private String city;
    
    @Column(length = 20)
    private String state;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTerminal() {
		return terminal;
	}

	public void setTerminal(String terminal) {
		this.terminal = terminal;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Location(int id, String terminal, String city, String state) {
		super();
		this.id = id;
		this.terminal = terminal;
		this.city = city;
		this.state = state;
	}

	public Location() {
		super();
	}
    
}

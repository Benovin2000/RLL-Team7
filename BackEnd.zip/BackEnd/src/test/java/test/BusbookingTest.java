package test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BusbookingTest {

private WebDriver driver=null;
	
	
	@BeforeTest
	public void InitalizeDriver() {
	
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			driver.manage().window().maximize();	
	}
	
	 @Test(priority=1)
		public void LaunchingApplication() {
			
			driver.get("http://localhost:4200/");
		 }
}
